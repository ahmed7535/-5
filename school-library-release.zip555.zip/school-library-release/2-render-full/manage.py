#!/usr/bin/env python3
"""Account management from the server's terminal.

    python3 manage.py list-users
    python3 manage.py create-admin USERNAME
    python3 manage.py reset-password USERNAME
"""
import argparse
import getpass
import sys

from library.db import db, init_db, normalize, now_iso
from library.security import hash_password


def read_password(args) -> str:
    if args.password:
        password = args.password
    else:
        password = getpass.getpass("Password (min 8 chars): ")
        if password != getpass.getpass("Repeat password: "):
            sys.exit("Passwords do not match.")
    if len(password) < 8:
        sys.exit("Password must be at least 8 characters.")
    return password


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="cmd", required=True)
    for name in ("create-admin", "reset-password"):
        p = sub.add_parser(name)
        p.add_argument("username")
        p.add_argument("--password", help="avoid: visible in shell history; prefer the prompt")
    sub.add_parser("list-users")
    sub.add_parser("list-admins")
    args = parser.parse_args()

    init_db()
    with db() as conn:
        if args.cmd in ("list-users", "list-admins"):
            sql = "SELECT username, role, is_active, created_at FROM users"
            if args.cmd == "list-admins":
                sql += " WHERE role = 'admin'"
            for row in conn.execute(sql + " ORDER BY id"):
                state = "active" if row["is_active"] else "DISABLED"
                print(f"{row['username']:<24} {row['role']:<6} {state:<9} (created {row['created_at']})")
        elif args.cmd == "create-admin":
            key = args.username.casefold()
            if conn.execute("SELECT 1 FROM users WHERE username_key = ?", (key,)).fetchone():
                sys.exit("That username already exists. Use reset-password.")
            conn.execute(
                "INSERT INTO users (full_name, username, username_key, password_hash, role, is_active, "
                "search_norm, created_at) VALUES (?, ?, ?, ?, 'admin', 1, ?, ?)",
                (args.username, args.username, key, hash_password(read_password(args)),
                 normalize(args.username), now_iso()),
            )
            print("Admin account created.")
        elif args.cmd == "reset-password":
            row = conn.execute("SELECT id FROM users WHERE username_key = ?", (args.username.casefold(),)).fetchone()
            if not row:
                sys.exit("No such user.")
            conn.execute("UPDATE users SET password_hash = ?, is_active = 1 WHERE id = ?",
                         (hash_password(read_password(args)), row["id"]))
            conn.execute("DELETE FROM sessions WHERE user_id = ?", (row["id"],))
            print("Password updated; account re-enabled; all its sessions signed out.")


if __name__ == "__main__":
    main()
