"""Server start-up."""
import signal
import threading
from http.server import ThreadingHTTPServer

from . import config
from .db import db, init_db, normalize, now_iso
from .handlers import Handler
from .security import hash_password


class LibraryServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def ensure_first_admin() -> None:
    """Create the first admin from SERVER settings if no admin exists yet.

    Credentials come from LIBRARY_ADMIN_USERNAME / LIBRARY_ADMIN_PASSWORD (see config.py);
    they are never part of any front-end file, and only a password hash is stored.
    """
    username, password = config.ADMIN_USERNAME, config.ADMIN_PASSWORD
    with db() as conn:
        if conn.execute("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1").fetchone():
            return
        if config.IS_PRODUCTION and (password == config.DEFAULT_ADMIN_PASSWORD or len(password) < 10):
            print("WARNING: no admin account exists and none was created. In production set a strong\n"
                  "  LIBRARY_ADMIN_PASSWORD (10+ characters, not the default) and restart, or run\n"
                  "  `python3 manage.py create-admin USERNAME` from the host's shell.", flush=True)
            return
        if conn.execute("SELECT 1 FROM users WHERE username_key = ?", (username.casefold(),)).fetchone():
            print(f"NOTE: no admin exists but username '{username}' is taken by a normal account. "
                  f"Set LIBRARY_ADMIN_USERNAME to another name.", flush=True)
            return
        conn.execute(
            "INSERT INTO users (full_name, username, username_key, password_hash, role, is_active, "
            "search_norm, created_at) VALUES (?, ?, ?, ?, 'admin', 1, ?, ?)",
            ("أمين المكتبة", username, username.casefold(), hash_password(password),
             normalize(f"أمين المكتبة {username}"), now_iso()),
        )
    # The password is never printed or logged.
    print(f"First run: admin account '{username}' created (password taken from LIBRARY_ADMIN_PASSWORD).", flush=True)
    if password == config.DEFAULT_ADMIN_PASSWORD:
        print("WARNING: the well-known default admin password is in use (local use only). Change it from the\n"
              "  dashboard (Account tab) or set LIBRARY_ADMIN_PASSWORD before the first run.", flush=True)


def main() -> None:
    init_db()
    ensure_first_admin()
    server = LibraryServer((config.HOST, config.PORT), Handler)
    mode = "production" if config.IS_PRODUCTION else "local"
    print(f"School Library ({mode}) listening on {config.HOST}:{config.PORT}  (dashboard: /admin/, health: /healthz)", flush=True)

    def _stop(signum, frame):  # Render sends SIGTERM on deploy/restart: finish cleanly
        threading.Thread(target=server.shutdown, daemon=True).start()

    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            signal.signal(sig, _stop)
        except ValueError:  # not the main thread
            pass
    try:
        server.serve_forever()
    finally:
        server.server_close()
        print("Stopped.", flush=True)
