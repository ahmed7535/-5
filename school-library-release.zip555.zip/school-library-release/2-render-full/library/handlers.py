"""HTTP layer: routing, JSON API endpoints and static file serving."""
import hmac
import json
import mimetypes
import re
import sqlite3
import sys
import traceback
import unicodedata
from datetime import datetime, timedelta, timezone
from http import cookies
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, unquote, urlsplit

from . import config
from .db import db, like_pattern, normalize, now_iso
from .security import (
    DUMMY_HASH,
    RateLimiter,
    hash_password,
    new_token,
    token_hash,
    verify_password,
)

# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

LOGIN_BY_USER = RateLimiter(limit=6, window=15 * 60)   # failed logins per ip+username
LOGIN_BY_IP = RateLimiter(limit=30, window=15 * 60)    # failed logins per ip
REQUESTS_BY_IP = RateLimiter(limit=60, window=60 * 60)  # book requests per ip (schools share one IP)
SIGNUP_BY_IP = RateLimiter(limit=20, window=60 * 60)     # new accounts per ip
COMPLAINTS_BY_IP = RateLimiter(limit=10, window=60 * 60)  # anonymous messages per ip (memory only)

SETTING_KEYS = {
    "welcome_title": 120,
    "welcome_subtitle": 200,
    "announcement": 300,
    "footer_text": 200,
}

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


class ApiError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def clean_text(value: str, multiline: bool = False) -> str:
    value = _CONTROL_CHARS.sub("", value.replace("\r\n", "\n").replace("\r", "\n"))
    if multiline:
        value = re.sub(r"\n{3,}", "\n\n", value)
        return value.strip()
    return re.sub(r"\s+", " ", value).strip()


def field(body, key, label, max_len, min_len=0, required=False, multiline=False):
    value = body.get(key, "")
    if value is None:
        value = ""
    if not isinstance(value, str):
        raise ApiError(400, f"قيمة «{label}» غير صالحة")
    value = clean_text(value, multiline)
    if not value:
        if required:
            raise ApiError(400, f"الرجاء إدخال «{label}»")
        return ""
    if len(value) < min_len:
        raise ApiError(400, f"«{label}» قصير جداً (الحد الأدنى {min_len} أحرف)")
    if len(value) > max_len:
        raise ApiError(400, f"«{label}» طويل جداً (الحد الأقصى {max_len} حرفاً)")
    return value


def parse_date(value):
    if value in (None, ""):
        return None
    if not isinstance(value, str):
        raise ApiError(400, "تاريخ غير صالح")
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        raise ApiError(400, "تاريخ غير صالح")
    return value


def to_int(value, label="المعرّف"):
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ApiError(400, f"{label} غير صالح")


def ok(**extra):
    return {"ok": True, **extra}


ROUTES = []


def route(method, pattern, admin=False, user=False):
    """Register an endpoint. admin=True -> role 'admin' only; user=True -> any signed-in account."""
    rx = re.compile("^" + pattern + "$")
    level = "admin" if admin else ("user" if user else None)

    def decorator(fn):
        ROUTES.append((method, rx, fn, level))
        return fn

    return decorator


# --------------------------------------------------------------------------
# Serialisers
# --------------------------------------------------------------------------

def comp_dict(row):
    return {
        "id": row["id"],
        "title": row["title"],
        "description": row["description"],
        "conditions": row["conditions"],
        "event_date": row["event_date"],
        "event_note": row["event_note"],
        "how_to_join": row["how_to_join"],
        "is_active": bool(row["is_active"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def book_dict(row):
    return {
        "id": row["id"],
        "title": row["title"],
        "author": row["author"],
        "description": row["description"],
        "status": row["status"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def request_dict(row):
    return {
        "id": row["id"],
        "student_name": row["student_name"],
        "class_name": row["class_name"],
        "book_title": row["book_title"],
        "notes": row["notes"],
        "status": row["status"],
        "admin_note": row["admin_note"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def get_settings(conn):
    data = {r["key"]: r["value"] for r in conn.execute("SELECT key, value FROM settings")}
    data["requests_open"] = data.get("requests_open", "1") == "1"
    return data


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------

@route("GET", r"/api/settings")
def public_settings(req, m, body):
    with db() as conn:
        return get_settings(conn)


@route("GET", r"/api/competitions")
def public_competitions(req, m, body):
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM competitions WHERE is_active = 1 "
            "ORDER BY event_date IS NULL, event_date DESC, id DESC"
        ).fetchall()
    return {"items": [comp_dict(r) for r in rows]}


@route("GET", r"/api/books")
def public_books(req, m, body):
    q = normalize(req.query_value("q"))[:100]
    sql = "SELECT * FROM books"
    params = []
    if q:
        sql += " WHERE (title_norm LIKE ? ESCAPE '\\' OR author_norm LIKE ? ESCAPE '\\')"
        params += [like_pattern(q), like_pattern(q)]
    sql += " ORDER BY CASE status WHEN 'required' THEN 0 WHEN 'available' THEN 1 ELSE 2 END, title_norm"
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"items": [book_dict(r) for r in rows]}


@route("POST", r"/api/requests")
def create_request(req, m, body):
    ip = req.client_ip
    if REQUESTS_BY_IP.blocked(ip):
        raise ApiError(429, "تم إرسال عدد كبير من الطلبات، حاول لاحقاً")
    with db() as conn:
        if not get_settings(conn)["requests_open"]:
            raise ApiError(403, "استقبال الطلبات متوقف حالياً")

    student = field(body, "student_name", "اسم الطالب", 80, min_len=2, required=True)
    klass = field(body, "class_name", "الفصل الدراسي", 60, required=True)
    title = field(body, "book_title", "اسم الكتاب", 150, min_len=2, required=True)
    notes = field(body, "notes", "الملاحظات", 500, multiline=True)

    # Honeypot: real students never see or fill this field. Pretend success to bots.
    if body.get("website"):
        return 201, ok(id=0)

    REQUESTS_BY_IP.hit(ip)
    ts = now_iso()
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO book_requests (student_name, class_name, book_title, notes, status, "
            "admin_note, search_norm, created_at, updated_at) VALUES (?,?,?,?, 'new', '', ?, ?, ?)",
            (student, klass, title, notes, normalize(f"{student} {klass} {title}"), ts, ts),
        )
    return 201, ok(id=cur.lastrowid)


# --------------------------------------------------------------------------
# Accounts: sign-up / login / logout. Students and admins use the same login;
# what each may do is decided on the SERVER by `role` (see route(level=...)).
# --------------------------------------------------------------------------

NAME_MAX = 30
USERNAME_RE = re.compile(r"^[\w.\-]{3,30}$")
RESERVED_USERNAMES = {"admin", "administrator", "root", "librarian", "support", "system"}
INACTIVE_MSG = "هذا الحساب معطّل. تواصل مع إدارة المكتبة"


def user_dict(row, admin_view=False):
    data = {
        "id": row["id"],
        "first_name": row["first_name"],
        "second_name": row["second_name"],
        "third_name": row["third_name"],
        "full_name": row["full_name"],
        "username": row["username"],
        "role": row["role"],
    }
    if admin_view:
        data["is_active"] = bool(row["is_active"])
        data["created_at"] = row["created_at"]
        data["last_login"] = row["last_login"]
    return data


def parse_person_name(body, key, label):
    value = field(body, key, label, NAME_MAX, min_len=2, required=True)
    ok_chars = all(ch.isalpha() or ch in " -'’" or unicodedata.category(ch) == "Mn" for ch in value)
    if not ok_chars:
        raise ApiError(400, f"«{label}» يجب أن يحتوي على حروف فقط")
    return value


def get_password(body, key, label="كلمة المرور"):
    value = body.get(key, "")
    if not isinstance(value, str):
        raise ApiError(400, f"«{label}» غير صالحة")
    return value


def check_new_password(password, username=""):
    if len(password) < 8:
        raise ApiError(400, "كلمة المرور يجب ألا تقل عن 8 أحرف")
    if len(password) > 128:
        raise ApiError(400, "كلمة المرور طويلة جداً (الحد الأقصى 128 حرفاً)")
    if username and password.casefold() == username.casefold():
        raise ApiError(400, "كلمة المرور يجب ألا تطابق اسم المستخدم")


def start_session(req, user_id, role):
    token, csrf = new_token(), new_token()
    hours = config.SESSION_HOURS if role == "admin" else config.SESSION_HOURS_USER
    now = datetime.now(timezone.utc)
    expires = (now + timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M:%SZ")
    with db() as conn:
        conn.execute("DELETE FROM sessions WHERE expires_at < ?", (now_iso(),))
        conn.execute(
            "INSERT INTO sessions (token_hash, user_id, csrf, created_at, expires_at) VALUES (?,?,?,?,?)",
            (token_hash(token), user_id, csrf, now_iso(), expires),
        )
        conn.execute("UPDATE users SET last_login = ? WHERE id = ?", (now_iso(), user_id))
    req.set_session_cookie(token, hours * 3600)
    return csrf


@route("POST", r"/api/signup")
def signup(req, m, body):
    ip = req.client_ip
    if SIGNUP_BY_IP.blocked(ip):
        raise ApiError(429, "تم إنشاء عدد كبير من الحسابات، حاول لاحقاً")
    first = parse_person_name(body, "first_name", "الاسم الأول")
    second = parse_person_name(body, "second_name", "الاسم الثاني")
    third = parse_person_name(body, "third_name", "الاسم الثالث")
    username = field(body, "username", "اسم المستخدم", 30, min_len=3, required=True)
    if not USERNAME_RE.match(username):
        raise ApiError(400, "اسم المستخدم من 3 إلى 30 حرفاً: حروف وأرقام و ( . _ - ) فقط وبدون مسافات")
    password = get_password(body, "password")
    confirm = get_password(body, "confirm_password", "تأكيد كلمة المرور")
    check_new_password(password, username)
    if password != confirm:
        raise ApiError(400, "تأكيد كلمة المرور غير مطابق")
    key = username.casefold()
    if key in RESERVED_USERNAMES:
        raise ApiError(409, "اسم المستخدم غير متاح، اختر اسماً آخر")

    SIGNUP_BY_IP.hit(ip)
    full = f"{first} {second} {third}"
    pw_hash = hash_password(password)
    try:
        with db() as conn:
            # One account per person: the same three-part name (ignoring tashkeel / alef variants) can't register twice.
            wanted = normalize(full)
            for (existing,) in conn.execute("SELECT full_name FROM users WHERE role = 'user'"):
                if normalize(existing) == wanted:
                    raise ApiError(409, "يوجد حساب بنفس الاسم الثلاثي، لا يمكن التسجيل بنفس الاسم مرتين")
            cur = conn.execute(
                # The role is ALWAYS 'user' here: public sign-up can never create an admin.
                "INSERT INTO users (first_name, second_name, third_name, full_name, username, username_key, "
                "password_hash, role, is_active, search_norm, created_at) VALUES (?,?,?,?,?,?,?, 'user', 1, ?, ?)",
                (first, second, third, full, username, key, pw_hash, normalize(f"{full} {username}"), now_iso()),
            )
            row = conn.execute("SELECT * FROM users WHERE id = ?", (cur.lastrowid,)).fetchone()
    except sqlite3.IntegrityError:
        raise ApiError(409, "اسم المستخدم مستخدم من قبل، اختر اسماً آخر")
    csrf = start_session(req, row["id"], row["role"])
    return 201, ok(user=user_dict(row), csrf=csrf)


def do_login(req, body, admin_only):
    ip = req.client_ip
    username = str(body.get("username", "")).strip()[:64]
    password = str(body.get("password", ""))[:256]
    key = username.casefold()
    user_key = f"{ip}|{key}"
    if LOGIN_BY_USER.blocked(user_key) or LOGIN_BY_IP.blocked(ip):
        raise ApiError(429, "محاولات دخول كثيرة. حاول مرة أخرى بعد 15 دقيقة")

    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE username_key = ?", (key,)).fetchone()
    valid = verify_password(password, row["password_hash"] if row else DUMMY_HASH)
    if not row or not valid:
        LOGIN_BY_USER.hit(user_key)
        LOGIN_BY_IP.hit(ip)
        raise ApiError(401, "اسم المستخدم أو كلمة المرور غير صحيحة")
    if not row["is_active"]:
        raise ApiError(403, INACTIVE_MSG)
    if admin_only and row["role"] != "admin":
        raise ApiError(403, "هذه الصفحة خاصة بإدارة المكتبة. للدخول كطالب استخدم صفحة «حسابك» في الموقع")

    LOGIN_BY_USER.clear(user_key)
    csrf = start_session(req, row["id"], row["role"])
    return ok(user=user_dict(row), csrf=csrf, username=row["username"])


@route("POST", r"/api/login")
def login(req, m, body):
    return do_login(req, body, admin_only=False)


@route("POST", r"/api/admin/login")
def admin_login(req, m, body):
    return do_login(req, body, admin_only=True)


@route("POST", r"/api/logout", user=True)
@route("POST", r"/api/admin/logout", admin=True)
def logout(req, m, body):
    with db() as conn:
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (req.user["token_hash"],))
    req.set_session_cookie("", 0)
    return ok()


@route("GET", r"/api/me")
def me(req, m, body):
    user = req.current_user()
    if not user:
        return {"user": None}
    return {"user": user_dict(user), "csrf": user["csrf"]}


@route("GET", r"/api/admin/me", admin=True)
def admin_me(req, m, body):
    return ok(id=req.user["id"], username=req.user["username"], csrf=req.user["csrf"])


@route("POST", r"/api/admin/password", admin=True)
def admin_password(req, m, body):
    current = get_password(body, "current")[:256]
    new = get_password(body, "new")
    check_new_password(new, req.user["username"])
    if new == current:
        raise ApiError(400, "كلمة المرور الجديدة يجب أن تختلف عن الحالية")
    with db() as conn:
        row = conn.execute("SELECT * FROM users WHERE id = ?", (req.user["id"],)).fetchone()
        if not verify_password(current, row["password_hash"]):
            raise ApiError(400, "كلمة المرور الحالية غير صحيحة")
        conn.execute("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(new), row["id"]))
        # Sign out every other session of this account.
        conn.execute(
            "DELETE FROM sessions WHERE user_id = ? AND token_hash != ?",
            (row["id"], req.user["token_hash"]),
        )
    return ok()


@route("GET", r"/api/admin/stats", admin=True)
def admin_stats(req, m, body):
    with db() as conn:
        one = lambda sql: conn.execute(sql).fetchone()[0]
        return {
            "new_requests": one("SELECT COUNT(*) FROM book_requests WHERE status = 'new'"),
            "requests": one("SELECT COUNT(*) FROM book_requests"),
            "competitions": one("SELECT COUNT(*) FROM competitions"),
            "books": one("SELECT COUNT(*) FROM books"),
            "users": one("SELECT COUNT(*) FROM users"),
            "new_complaints": one("SELECT COUNT(*) FROM complaints WHERE status = 'new'"),
        }


# --------------------------------------------------------------------------
# Admin: user management (every route below is admin-only, enforced server-side)
# --------------------------------------------------------------------------

@route("GET", r"/api/admin/users", admin=True)
def admin_users(req, m, body):
    q = normalize(req.query_value("q"))[:100]
    flt = req.query_value("filter")
    where, params = [], []
    if q:
        where.append("search_norm LIKE ? ESCAPE '\\'")
        params.append(like_pattern(q))
    if flt == "active":
        where.append("is_active = 1")
    elif flt == "disabled":
        where.append("is_active = 0")
    elif flt == "admin":
        where.append("role = 'admin'")
    elif flt:
        raise ApiError(400, "فلتر غير صالح")
    sql = "SELECT * FROM users"
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at DESC, id DESC LIMIT 500"
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
        c = conn.execute(
            "SELECT COUNT(*) AS total, COALESCE(SUM(is_active = 1), 0) AS active, "
            "COALESCE(SUM(is_active = 0), 0) AS disabled, COALESCE(SUM(role = 'admin'), 0) AS admins FROM users"
        ).fetchone()
    return {"items": [user_dict(r, admin_view=True) for r in rows], "counts": dict(c)}


@route("PATCH", r"/api/admin/users/(\d+)", admin=True)
def admin_user_update(req, m, body):
    uid = to_int(m.group(1))
    if uid == req.user["id"]:
        raise ApiError(400, "لا يمكنك تعديل حسابك من هنا (حتى لا تفقد صلاحية الدخول). غيّر كلمة مرورك من تبويب «الحساب»")
    sets, params, revoke = [], [], False
    if "is_active" in body:
        if not isinstance(body["is_active"], bool):
            raise ApiError(400, "قيمة غير صالحة")
        sets.append("is_active = ?")
        params.append(1 if body["is_active"] else 0)
        revoke = revoke or not body["is_active"]
    if "role" in body:
        if body["role"] not in config.ROLES:
            raise ApiError(400, "صلاحية غير صالحة")
        sets.append("role = ?")
        params.append(body["role"])
    if "new_password" in body:
        pw = get_password(body, "new_password", "كلمة المرور الجديدة")
        check_new_password(pw)
        sets.append("password_hash = ?")
        params.append(hash_password(pw))
        revoke = True
    if not sets:
        raise ApiError(400, "لا توجد تغييرات")
    with db() as conn:
        cur = conn.execute(f"UPDATE users SET {', '.join(sets)} WHERE id = ?", params + [uid])
        if cur.rowcount == 0:
            raise ApiError(404, "المستخدم غير موجود")
        if revoke:
            conn.execute("DELETE FROM sessions WHERE user_id = ?", (uid,))
        row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    return user_dict(row, admin_view=True)


@route("DELETE", r"/api/admin/users/(\d+)", admin=True)
def admin_user_delete(req, m, body):
    uid = to_int(m.group(1))
    if uid == req.user["id"]:
        raise ApiError(400, "لا يمكنك حذف حسابك الحالي")
    with db() as conn:
        cur = conn.execute("DELETE FROM users WHERE id = ?", (uid,))  # sessions cascade
        if cur.rowcount == 0:
            raise ApiError(404, "المستخدم غير موجود")
    return ok()


# --------------------------------------------------------------------------
# Anonymous complaints box ("المشاكل اللي شايفها في المدرسة")
# Nothing that identifies the sender is read or stored: no session, no user id,
# no IP, no time of day. The access log also skips this endpoint (see Handler).
# --------------------------------------------------------------------------

@route("POST", r"/api/complaints")
def create_complaint(req, m, body):
    ip = req.client_ip
    if COMPLAINTS_BY_IP.blocked(ip):
        raise ApiError(429, "تم إرسال عدد كبير من الرسائل، حاول لاحقاً")
    message = field(body, "message", "الرسالة", 1500, min_len=5, required=True, multiline=True)
    if body.get("website"):  # honeypot
        return 201, ok()
    COMPLAINTS_BY_IP.hit(ip)  # in memory only, never written to the database
    with db() as conn:
        conn.execute(
            "INSERT INTO complaints (message, status, created_on) VALUES (?, 'new', ?)",
            (message, now_iso()[:10]),
        )
    return 201, ok()


def complaint_dict(row):
    return {"id": row["id"], "message": row["message"], "status": row["status"], "created_on": row["created_on"]}


@route("GET", r"/api/admin/complaints", admin=True)
def admin_complaints(req, m, body):
    status = req.query_value("status")
    sql, params = "SELECT * FROM complaints", []
    if status:
        if status not in config.COMPLAINT_STATUSES:
            raise ApiError(400, "حالة غير صالحة")
        sql += " WHERE status = ?"
        params.append(status)
    sql += " ORDER BY id DESC LIMIT 500"
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
        counts = {s: 0 for s in config.COMPLAINT_STATUSES}
        for r in conn.execute("SELECT status, COUNT(*) AS n FROM complaints GROUP BY status"):
            counts[r["status"]] = r["n"]
    return {"items": [complaint_dict(r) for r in rows], "counts": counts}


@route("PATCH", r"/api/admin/complaints/(\d+)", admin=True)
def admin_complaint_update(req, m, body):
    cid = to_int(m.group(1))
    if body.get("status") not in config.COMPLAINT_STATUSES:
        raise ApiError(400, "حالة غير صالحة")
    with db() as conn:
        cur = conn.execute("UPDATE complaints SET status = ? WHERE id = ?", (body["status"], cid))
        if cur.rowcount == 0:
            raise ApiError(404, "الرسالة غير موجودة")
        row = conn.execute("SELECT * FROM complaints WHERE id = ?", (cid,)).fetchone()
    return complaint_dict(row)


@route("DELETE", r"/api/admin/complaints/(\d+)", admin=True)
def admin_complaint_delete(req, m, body):
    with db() as conn:
        cur = conn.execute("DELETE FROM complaints WHERE id = ?", (to_int(m.group(1)),))
        if cur.rowcount == 0:
            raise ApiError(404, "الرسالة غير موجودة")
    return ok()


# --------------------------------------------------------------------------
# Admin: competitions
# --------------------------------------------------------------------------

def parse_competition(body):
    return {
        "title": field(body, "title", "اسم المسابقة", 150, min_len=2, required=True),
        "description": field(body, "description", "وصف المسابقة", 1500, multiline=True),
        "conditions": field(body, "conditions", "شروط الاشتراك", 1500, multiline=True),
        "event_date": parse_date(body.get("event_date")),
        "event_note": field(body, "event_note", "ملاحظة الموعد", 150),
        "how_to_join": field(body, "how_to_join", "طريقة المشاركة", 1500, multiline=True),
        "is_active": 1 if body.get("is_active", True) else 0,
    }


@route("GET", r"/api/admin/competitions", admin=True)
def admin_competitions(req, m, body):
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM competitions ORDER BY event_date IS NULL, event_date DESC, id DESC"
        ).fetchall()
    return {"items": [comp_dict(r) for r in rows]}


@route("POST", r"/api/admin/competitions", admin=True)
def admin_competition_create(req, m, body):
    d = parse_competition(body)
    ts = now_iso()
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO competitions (title, description, conditions, event_date, event_note, "
            "how_to_join, is_active, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (d["title"], d["description"], d["conditions"], d["event_date"], d["event_note"],
             d["how_to_join"], d["is_active"], ts, ts),
        )
        row = conn.execute("SELECT * FROM competitions WHERE id = ?", (cur.lastrowid,)).fetchone()
    return 201, comp_dict(row)


@route("PUT", r"/api/admin/competitions/(\d+)", admin=True)
def admin_competition_update(req, m, body):
    cid = to_int(m.group(1))
    d = parse_competition(body)
    with db() as conn:
        cur = conn.execute(
            "UPDATE competitions SET title=?, description=?, conditions=?, event_date=?, event_note=?, "
            "how_to_join=?, is_active=?, updated_at=? WHERE id=?",
            (d["title"], d["description"], d["conditions"], d["event_date"], d["event_note"],
             d["how_to_join"], d["is_active"], now_iso(), cid),
        )
        if cur.rowcount == 0:
            raise ApiError(404, "المسابقة غير موجودة")
        row = conn.execute("SELECT * FROM competitions WHERE id = ?", (cid,)).fetchone()
    return comp_dict(row)


@route("DELETE", r"/api/admin/competitions/(\d+)", admin=True)
def admin_competition_delete(req, m, body):
    with db() as conn:
        cur = conn.execute("DELETE FROM competitions WHERE id = ?", (to_int(m.group(1)),))
        if cur.rowcount == 0:
            raise ApiError(404, "المسابقة غير موجودة")
    return ok()


# --------------------------------------------------------------------------
# Admin: required books
# --------------------------------------------------------------------------

def parse_book(body):
    status = body.get("status", "required")
    if status not in config.BOOK_STATUSES:
        raise ApiError(400, "حالة الكتاب غير صالحة")
    title = field(body, "title", "اسم الكتاب", 200, min_len=2, required=True)
    author = field(body, "author", "اسم المؤلف", 120)
    return {
        "title": title,
        "title_norm": normalize(title),
        "author": author,
        "author_norm": normalize(author),
        "description": field(body, "description", "الوصف المختصر", 1000, multiline=True),
        "status": status,
    }


@route("GET", r"/api/admin/books", admin=True)
def admin_books(req, m, body):
    q = normalize(req.query_value("q"))[:100]
    sql, params = "SELECT * FROM books", []
    if q:
        sql += " WHERE (title_norm LIKE ? ESCAPE '\\' OR author_norm LIKE ? ESCAPE '\\')"
        params += [like_pattern(q), like_pattern(q)]
    sql += " ORDER BY title_norm"
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
    return {"items": [book_dict(r) for r in rows]}


@route("POST", r"/api/admin/books", admin=True)
def admin_book_create(req, m, body):
    d = parse_book(body)
    ts = now_iso()
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO books (title, title_norm, author, author_norm, description, status, "
            "created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)",
            (d["title"], d["title_norm"], d["author"], d["author_norm"], d["description"],
             d["status"], ts, ts),
        )
        row = conn.execute("SELECT * FROM books WHERE id = ?", (cur.lastrowid,)).fetchone()
    return 201, book_dict(row)


@route("PUT", r"/api/admin/books/(\d+)", admin=True)
def admin_book_update(req, m, body):
    bid = to_int(m.group(1))
    d = parse_book(body)
    with db() as conn:
        cur = conn.execute(
            "UPDATE books SET title=?, title_norm=?, author=?, author_norm=?, description=?, "
            "status=?, updated_at=? WHERE id=?",
            (d["title"], d["title_norm"], d["author"], d["author_norm"], d["description"],
             d["status"], now_iso(), bid),
        )
        if cur.rowcount == 0:
            raise ApiError(404, "الكتاب غير موجود")
        row = conn.execute("SELECT * FROM books WHERE id = ?", (bid,)).fetchone()
    return book_dict(row)


@route("DELETE", r"/api/admin/books/(\d+)", admin=True)
def admin_book_delete(req, m, body):
    with db() as conn:
        cur = conn.execute("DELETE FROM books WHERE id = ?", (to_int(m.group(1)),))
        if cur.rowcount == 0:
            raise ApiError(404, "الكتاب غير موجود")
    return ok()


# --------------------------------------------------------------------------
# Admin: student book requests
# --------------------------------------------------------------------------

@route("GET", r"/api/admin/requests", admin=True)
def admin_requests(req, m, body):
    q = normalize(req.query_value("q"))[:100]
    status = req.query_value("status")
    sql, params, where = "SELECT * FROM book_requests", [], []
    if q:
        where.append("search_norm LIKE ? ESCAPE '\\'")
        params.append(like_pattern(q))
    if status:
        if status not in config.REQUEST_STATUSES:
            raise ApiError(400, "حالة غير صالحة")
        where.append("status = ?")
        params.append(status)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY created_at DESC, id DESC LIMIT 500"
    with db() as conn:
        rows = conn.execute(sql, params).fetchall()
        counts = {s: 0 for s in config.REQUEST_STATUSES}
        for r in conn.execute("SELECT status, COUNT(*) AS n FROM book_requests GROUP BY status"):
            counts[r["status"]] = r["n"]
    return {"items": [request_dict(r) for r in rows], "counts": counts}


@route("PATCH", r"/api/admin/requests/(\d+)", admin=True)
def admin_request_update(req, m, body):
    rid = to_int(m.group(1))
    sets, params = [], []
    if "status" in body:
        if body["status"] not in config.REQUEST_STATUSES:
            raise ApiError(400, "حالة الطلب غير صالحة")
        sets.append("status = ?")
        params.append(body["status"])
    if "admin_note" in body:
        sets.append("admin_note = ?")
        params.append(field(body, "admin_note", "ملاحظة الإدارة", 500, multiline=True))
    if not sets:
        raise ApiError(400, "لا توجد تغييرات")
    sets.append("updated_at = ?")
    params += [now_iso(), rid]
    with db() as conn:
        cur = conn.execute(f"UPDATE book_requests SET {', '.join(sets)} WHERE id = ?", params)
        if cur.rowcount == 0:
            raise ApiError(404, "الطلب غير موجود")
        row = conn.execute("SELECT * FROM book_requests WHERE id = ?", (rid,)).fetchone()
    return request_dict(row)


@route("DELETE", r"/api/admin/requests/(\d+)", admin=True)
def admin_request_delete(req, m, body):
    with db() as conn:
        cur = conn.execute("DELETE FROM book_requests WHERE id = ?", (to_int(m.group(1)),))
        if cur.rowcount == 0:
            raise ApiError(404, "الطلب غير موجود")
    return ok()


# --------------------------------------------------------------------------
# Admin: site content
# --------------------------------------------------------------------------

@route("PUT", r"/api/admin/settings", admin=True)
def admin_settings(req, m, body):
    values = {
        "welcome_title": field(body, "welcome_title", "عنوان الترحيب", SETTING_KEYS["welcome_title"], min_len=2, required=True),
        "welcome_subtitle": field(body, "welcome_subtitle", "عبارة الترحيب", SETTING_KEYS["welcome_subtitle"]),
        "announcement": field(body, "announcement", "إعلان الصفحة الرئيسية", SETTING_KEYS["announcement"]),
        "footer_text": field(body, "footer_text", "نص أسفل الصفحة", SETTING_KEYS["footer_text"]),
        "requests_open": "1" if body.get("requests_open", True) else "0",
    }
    with db() as conn:
        for key, value in values.items():
            conn.execute(
                "INSERT INTO settings (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
                (key, value),
            )
        return get_settings(conn)


# --------------------------------------------------------------------------
# Request handler
# --------------------------------------------------------------------------

CONTENT_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".svg": "image/svg+xml",
    ".json": "application/json; charset=utf-8",
    ".ico": "image/x-icon",
    ".png": "image/png",
    ".webp": "image/webp",
    ".woff2": "font/woff2",
}

CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
    "font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; "
    "frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
)


class Handler(BaseHTTPRequestHandler):
    server_version = "SchoolLibrary"
    sys_version = ""
    timeout = 20  # drop stalled connections

    # --- plumbing ---------------------------------------------------------
    def log_message(self, fmt, *args):
        # The anonymous complaints endpoint must leave no trace of who/when in the server log.
        if args and "/api/complaints" in str(args[0]):
            return
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def do_GET(self):
        self._dispatch("GET")

    def do_HEAD(self):
        self._dispatch("GET")

    def do_POST(self):
        self._dispatch("POST")

    def do_PUT(self):
        self._dispatch("PUT")

    def do_PATCH(self):
        self._dispatch("PATCH")

    def do_DELETE(self):
        self._dispatch("DELETE")

    @property
    def client_ip(self):
        if config.TRUST_PROXY:
            forwarded = self.headers.get("X-Forwarded-For", "")
            if forwarded:
                return forwarded.split(",")[-1].strip()
        return self.client_address[0]

    def query_value(self, name):
        return (self.query.get(name, [""])[0] or "").strip()

    def set_session_cookie(self, token, max_age):
        parts = [f"{config.SESSION_COOKIE}={token}", "Path=/", "HttpOnly", "SameSite=Strict", f"Max-Age={max_age}"]
        if config.COOKIE_SECURE:
            parts.append("Secure")
        self.extra_headers.append(("Set-Cookie", "; ".join(parts)))

    def _dispatch(self, method):
        self.extra_headers = []
        self.admin = None
        self.user = None
        self._user_loaded = False
        try:
            parts = urlsplit(self.path)
            self.query = parse_qs(parts.query, keep_blank_values=True)
            if parts.path in ("/healthz", "/health"):
                self._health()
            elif parts.path.startswith("/api/"):
                self._handle_api(method, parts.path)
            elif method == "GET":
                self._serve_static(parts.path)
            else:
                raise ApiError(405, "الطريقة غير مسموحة")
        except ApiError as err:
            self._send_error(err.message, err.status)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception:
            traceback.print_exc()
            self._send_error("حدث خطأ غير متوقع في الخادم", 500)

    # --- API --------------------------------------------------------------
    def _handle_api(self, method, path):
        path_matched = False
        for route_method, rx, fn, level in ROUTES:
            match = rx.match(path)
            if not match:
                continue
            path_matched = True
            if route_method != method:
                continue
            body = self._read_json() if method in ("POST", "PUT", "PATCH") else {}
            if level:
                user = self.current_user()
                if not user:
                    raise ApiError(401, "يجب تسجيل الدخول أولاً")
                # Role-based access control, decided here on the server for every request.
                if level == "admin" and user["role"] != "admin":
                    raise ApiError(403, "ليس لديك صلاحية للوصول إلى هذه الصفحة")
                if level == "admin":
                    self.admin = user
                if method != "GET":
                    sent = self.headers.get("X-CSRF-Token", "")
                    if not hmac.compare_digest(sent, user["csrf"]):
                        raise ApiError(403, "رمز الحماية غير صالح، أعد تحميل الصفحة")
            result = fn(self, match, body)
            status, payload = result if isinstance(result, tuple) else (200, result)
            self._send_json(payload, status)
            return
        raise ApiError(405 if path_matched else 404, "الطلب غير موجود")

    def _read_json(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError(400, "طلب غير صالح")
        if length > config.MAX_BODY_BYTES:
            raise ApiError(413, "حجم البيانات كبير جداً")
        if length == 0:
            return {}
        if not (self.headers.get("Content-Type") or "").startswith("application/json"):
            raise ApiError(415, "نوع المحتوى غير مدعوم")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ApiError(400, "بيانات غير صالحة")
        if not isinstance(data, dict):
            raise ApiError(400, "بيانات غير صالحة")
        return data

    def current_user(self):
        """The signed-in account for this request (cached), or None."""
        if not self._user_loaded:
            self.user = self._load_user()
            self._user_loaded = True
        return self.user

    def _load_user(self):
        header = self.headers.get("Cookie")
        if not header:
            return None
        jar = cookies.SimpleCookie()
        try:
            jar.load(header)
        except cookies.CookieError:
            return None
        morsel = jar.get(config.SESSION_COOKIE)
        if not morsel or not morsel.value:
            return None
        hashed = token_hash(morsel.value)
        with db() as conn:
            row = conn.execute(
                "SELECT s.token_hash, s.csrf, s.expires_at, u.id, u.username, u.full_name, u.first_name, "
                "u.second_name, u.third_name, u.role FROM sessions s JOIN users u ON u.id = s.user_id "
                "WHERE s.token_hash = ? AND u.is_active = 1",
                (hashed,),
            ).fetchone()
            if not row:
                return None
            if row["expires_at"] < now_iso():
                conn.execute("DELETE FROM sessions WHERE token_hash = ?", (hashed,))
                return None
        return dict(row)

    # --- responses --------------------------------------------------------
    def _security_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Content-Security-Policy", CSP)
        if config.COOKIE_SECURE:
            self.send_header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

    def _health(self):
        """Cheap liveness + database check for the host's health monitor."""
        try:
            with db() as conn:
                conn.execute("SELECT 1").fetchone()
        except Exception:
            traceback.print_exc()
            return self._send_json({"status": "error"}, 503)
        self._send_json({"status": "ok"})

    def _send_error(self, message, status):
        """JSON for /api/ calls, a friendly Arabic page for browser navigation (404, 500, ...)."""
        if urlsplit(self.path).path.startswith("/api/"):
            return self._send_json({"error": message}, status)
        title = {404: "الصفحة غير موجودة", 500: "حدث خطأ في الخادم"}.get(status, "تعذّر إكمال الطلب")
        page = (
            '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            f"<title>{status} — {title}</title>"
            '<link rel="stylesheet" href="/css/style.css"></head><body>'
            '<main style="min-height:80vh;display:grid;place-items:center;text-align:center;padding:24px">'
            f'<div><h1 style="font-size:64px;margin:0">{status}</h1><h2>{title}</h2><p>{message}</p>'
            '<p><a class="btn gold" href="/">العودة إلى الصفحة الرئيسية</a></p></div></main></body></html>'
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.send_header("Cache-Control", "no-store")
        self._security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(page)

    def _send_json(self, payload, status=200):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for key, value in self.extra_headers:
            self.send_header(key, value)
        self._security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)

    def _redirect(self, location):
        self.send_response(301)
        self.send_header("Location", location)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _serve_static(self, path):
        rel = unquote(path).lstrip("/")
        if "\x00" in rel or any(part.startswith(".") for part in rel.split("/") if part):
            raise ApiError(404, "الصفحة غير موجودة")
        if rel == "admin":
            return self._redirect("/admin/")
        root = config.STATIC_DIR.resolve()
        target = (root / rel).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            raise ApiError(404, "الصفحة غير موجودة")
        if target.is_dir():
            target = target / "index.html"
        if not target.is_file():
            raise ApiError(404, "الصفحة غير موجودة")
        content_type = CONTENT_TYPES.get(target.suffix.lower()) or mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        data = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-cache")
        self._security_headers()
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(data)
