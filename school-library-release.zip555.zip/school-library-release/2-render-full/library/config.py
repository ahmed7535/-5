"""Central configuration. Everything can be overridden with environment variables."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = Path(os.environ.get("LIBRARY_DATA_DIR", BASE_DIR / "data"))
DB_PATH = DATA_DIR / "library.db"

# Production mode is on when LIBRARY_ENV=production, or automatically on Render (RENDER env var).
# Locally (neither set) everything keeps working exactly as before.
IS_PRODUCTION = os.environ.get("LIBRARY_ENV", "").lower() == "production" or bool(os.environ.get("RENDER"))


def _flag(name: str, default: bool) -> bool:
    value = os.environ.get(name)
    return default if value is None else value.strip() == "1"


# Cloud hosts inject PORT and need 0.0.0.0. Locally the default stays 127.0.0.1 (private).
# LIBRARY_HOST / LIBRARY_PORT still win when set explicitly.
_PORT_FROM_HOST = os.environ.get("PORT")
HOST = os.environ.get("LIBRARY_HOST") or ("0.0.0.0" if (_PORT_FROM_HOST or IS_PRODUCTION) else "127.0.0.1")
PORT = int(os.environ.get("LIBRARY_PORT") or _PORT_FROM_HOST or "8000")

# HTTPS-only cookies + trusting the host's reverse proxy default to ON in production.
COOKIE_SECURE = _flag("LIBRARY_COOKIE_SECURE", IS_PRODUCTION)
TRUST_PROXY = _flag("LIBRARY_TRUST_PROXY", IS_PRODUCTION)

SESSION_COOKIE = "lib_session"
SESSION_HOURS = 8                 # admin sessions (short on purpose)
SESSION_HOURS_USER = 24 * 14      # student sessions stay signed in across page refreshes

# First admin account, created by the SERVER on first run if no admin exists yet.
# It never appears in any front-end file. Override with environment variables.
# In production the well-known default password is REFUSED: LIBRARY_ADMIN_PASSWORD must be set.
DEFAULT_ADMIN_PASSWORD = "1234567890"
ADMIN_USERNAME = os.environ.get("LIBRARY_ADMIN_USERNAME", "مكتبة مدرسة تونا الجبل الثانوية المشتركة")
ADMIN_PASSWORD = os.environ.get("LIBRARY_ADMIN_PASSWORD", DEFAULT_ADMIN_PASSWORD)
MAX_BODY_BYTES = 64 * 1024

# Visible status values (labels are defined in the front-end).
BOOK_STATUSES = ("required", "available", "closed")
REQUEST_STATUSES = ("new", "reviewing", "ready", "unavailable", "delivered")
COMPLAINT_STATUSES = ("new", "read")
ROLES = ("user", "admin")
