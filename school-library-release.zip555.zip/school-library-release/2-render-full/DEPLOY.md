# نشر «مكتبة مدرستنا» على Render (خطوة بخطوة)

> **مهم:** قاعدة البيانات SQLite وتحتاج **Persistent Disk** حتى لا تضيع البيانات عند إعادة التشغيل أو النشر.
> الـ Disk متاح فقط في خطط Render **المدفوعة** (Starter فما فوق، حوالي 7 دولار شهرياً + تكلفة القرص الصغيرة).
> الخطة المجانية تمسح الملفات عند كل إعادة تشغيل — **لا تستخدمها للبيانات الحقيقية**.
> هذا الملف تعليمات فقط؛ لم يتم نشر الموقع فعلياً من طرفي.

## 1) ارفع المشروع إلى GitHub
```bash
cd school-library
git init && git add . && git commit -m "School Library"
# أنشئ مستودعاً خاصاً (Private) على GitHub ثم:
git remote add origin https://github.com/USERNAME/school-library.git
git push -u origin main
```
ملف `.gitignore` يمنع رفع قاعدة البيانات (`data/`).

## 2) أنشئ الخدمة على Render
1. من لوحة Render: **New ▸ Blueprint** ثم اختر المستودع. سيقرأ `render.yaml` تلقائياً.
2. سيطلب منك قيمتين سريتين (لا تُحفظان في الكود):
   - `LIBRARY_ADMIN_USERNAME` — اسم دخول الأدمن (مثال: `مكتبة مدرسة تونا الجبل الثانوية المشتركة`).
   - `LIBRARY_ADMIN_PASSWORD` — كلمة مرور قوية (10 أحرف فأكثر، وليست `1234567890`).
3. اضغط **Apply**. انتظر حتى تصبح الحالة **Live**، ثم افتح الرابط `https://school-library-xxxx.onrender.com`.

(لو فضّلت يدوياً: New ▸ Web Service، Runtime = Python، Build = `pip install -r requirements.txt`، Start = `python3 run.py`،
Health Check Path = `/healthz`، أضف Disk باسم `library-data` ومسار `/var/data`، وأضف المتغيرات أدناه.)

## 3) متغيرات البيئة
| المتغير | القيمة | ملاحظات |
|---|---|---|
| `LIBRARY_ENV` | `production` | يفعّل Secure Cookies وHSTS وثقة الوكيل ويرفض كلمة المرور الافتراضية |
| `LIBRARY_DATA_DIR` | `/var/data` | **يجب** أن يطابق مسار الـ Disk |
| `LIBRARY_ADMIN_USERNAME` | اسمك | يُستخدم فقط عند أول تشغيل إن لم يوجد أدمن |
| `LIBRARY_ADMIN_PASSWORD` | كلمة قوية | تُخزَّن مشفّرة ولا تُطبع في السجل |
| `PYTHON_VERSION` | `3.12.3` | اختياري |
| `PORT` | يضعه Render تلقائياً | الخادم يقرؤه ويستمع على `0.0.0.0` |
| `LIBRARY_COOKIE_SECURE` / `LIBRARY_TRUST_PROXY` | `1` تلقائياً في الإنتاج | لا حاجة لضبطهما |
| `LIBRARY_HOST` / `LIBRARY_PORT` | اختياري | للتجاوز اليدوي فقط |

## 4) حساب الأدمن الأول بأمان
- الأفضل: ضع `LIBRARY_ADMIN_USERNAME` و`LIBRARY_ADMIN_PASSWORD` في Render قبل أول تشغيل؛ يُنشأ الأدمن مرة واحدة تلقائياً.
- أو من **Shell** الخدمة على Render (يسأل عن كلمة المرور دون إظهارها):
  ```bash
  python3 manage.py create-admin "اسم_الأدمن"
  python3 manage.py reset-password "اسم_الأدمن"   # عند نسيان كلمة المرور
  ```
- بعد الدخول من `/admin/` يمكنك تغيير كلمة المرور من تبويب «الحساب». يمكنك بعدها حذف `LIBRARY_ADMIN_PASSWORD` من Render.
- إن لم تضع كلمة مرور قوية في الإنتاج، **لن يُنشأ أدمن** وسيظهر تحذير في السجل (هذا مقصود).

## 5) التحقق بعد النشر
- `https://رابطك/` الصفحة الرئيسية، و`/admin/` لوحة الإدارة، و`/healthz` يعرض `{"status": "ok"}`.
- أنشئ حساب طالب تجريبي ثم احذفه من اللوحة.
- من لوحة Render اضغط **Manual Deploy ▸ Restart** وتأكد أن الكتب والحسابات ما زالت موجودة.

## 6) النسخ الاحتياطي
فعّل **Disk Snapshots** من إعدادات القرص في Render (تُحفظ يومياً). ولنسخة يدوية من الـ Shell:
```bash
sqlite3 /var/data/library.db ".backup '/var/data/backup.db'"
```
(إن لم يتوفر `sqlite3` استخدم: `python3 -c "import sqlite3;s=sqlite3.connect('/var/data/library.db');d=sqlite3.connect('/var/data/backup.db');s.backup(d)"`)

## 7) تشغيل الاختبارات محلياً
```bash
python3 tests/test_e2e.py
```
