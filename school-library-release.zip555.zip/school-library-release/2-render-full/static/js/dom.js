// Shared helpers: DOM builder, API client, formatting. No user data is ever put into innerHTML.

export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'svg') el.innerHTML = v; // trusted, static icon markup only
    else if (['value', 'checked', 'disabled', 'selected', 'required'].includes(k)) el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  const add = (c) => {
    if (c == null || c === false) return;
    if (Array.isArray(c)) return c.forEach(add);
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  };
  children.forEach(add);
  return el;
}

export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

let csrfToken = '';
export const setCsrf = (t) => { csrfToken = t || ''; };

export async function api(method, url, body) {
  const opts = { method, headers: {}, credentials: 'same-origin' };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  if (method !== 'GET') opts.headers['X-CSRF-Token'] = csrfToken;
  let res;
  try {
    res = await fetch(url, opts);
  } catch {
    throw new ApiError(0, 'تعذّر الاتصال بالخادم، تحقق من الاتصال وحاول مرة أخرى');
  }
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new ApiError(res.status, data.error || 'حدث خطأ غير متوقع');
  return data;
}

export const REQUEST_STATUS = {
  new: 'جديد',
  reviewing: 'قيد المراجعة',
  ready: 'جاهز للاستلام',
  unavailable: 'غير متوفر',
  delivered: 'تم التسليم',
};

export const BOOK_STATUS = {
  required: 'مطلوب',
  available: 'متوفر في المكتبة',
  closed: 'غير متاح حالياً',
};

export function fmtDate(ymd) {
  if (!ymd) return '';
  const [y, m, d] = ymd.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString('ar-EG', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });
}

export function fmtDateTime(iso) {
  return new Date(iso).toLocaleString('ar-EG', { dateStyle: 'medium', timeStyle: 'short' });
}

export function debounce(fn, ms = 300) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

export function toast(message, kind = 'ok') {
  let box = document.getElementById('toasts');
  if (!box) {
    box = h('div', { id: 'toasts', 'aria-live': 'polite' });
    document.body.append(box);
  }
  const t = h('div', { class: `toast ${kind}` }, message);
  box.append(t);
  setTimeout(() => t.remove(), 3500);
}
