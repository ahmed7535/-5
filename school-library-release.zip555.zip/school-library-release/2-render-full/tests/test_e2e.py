"""End-to-end tests: starts the real server on a temp database and drives every API.  python3 tests/test_e2e.py"""
import json, os, subprocess, sys, tempfile, time, urllib.request, urllib.error, socket

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
results = []


def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if (extra and not cond) else ""), flush=True)


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def start(env_extra, data_dir, port):
    env = {**os.environ, "LIBRARY_DATA_DIR": data_dir, "LIBRARY_PORT": str(port), **env_extra}
    for k in ("PORT", "RENDER", "LIBRARY_ENV"):
        if k not in env_extra: env.pop(k, None)
    proc = subprocess.Popen([sys.executable, "run.py"], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for _ in range(100):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/healthz", timeout=1); return proc
        except Exception:
            time.sleep(0.1)
    proc.kill(); raise SystemExit("server did not start:\n" + proc.stdout.read())


class Client:
    def __init__(self, port): self.base = f"http://127.0.0.1:{port}"; self.cookie = ""; self.csrf = ""
    def req(self, method, path, body=None, raw=False):
        data = json.dumps(body).encode() if body is not None else None
        r = urllib.request.Request(self.base + path, data=data, method=method)
        if data is not None: r.add_header("Content-Type", "application/json")
        if self.cookie: r.add_header("Cookie", self.cookie)
        if method != "GET": r.add_header("X-CSRF-Token", self.csrf)
        try:
            resp = urllib.request.urlopen(r, timeout=10)
        except urllib.error.HTTPError as e:
            resp = e
        for h, v in resp.headers.items():
            if h.lower() == "set-cookie":
                self.cookie = v.split(";")[0] if "Max-Age=0" not in v else ""
        payload = resp.read()
        if raw: return resp.status, payload, resp.headers
        try: j = json.loads(payload)
        except Exception: j = {}
        if isinstance(j, dict) and j.get("csrf"): self.csrf = j["csrf"]
        return resp.status, j


def main():
    tmp = tempfile.mkdtemp(); port = free_port()
    ADMIN = ("مكتبة تونا", "Str0ng-Admin-Pass!")
    env = {"LIBRARY_ADMIN_USERNAME": ADMIN[0], "LIBRARY_ADMIN_PASSWORD": ADMIN[1]}
    proc = start(env, tmp, port)
    c, adm = Client(port), Client(port)

    # ---- static / pages / errors ----
    for path, ctype in [("/", "text/html"), ("/admin/", "text/html"), ("/css/style.css", "text/css"), ("/js/app.js", "javascript"),
                        ("/js/dom.js", "javascript"), ("/admin/admin.js", "javascript"), ("/admin/admin.css", "text/css"), ("/favicon.svg", "svg")]:
        st, body, h = c.req("GET", path, raw=True)
        check(f"GET {path} -> 200 {ctype}", st == 200 and ctype in h.get("Content-Type", "") and len(body) > 50)
    st, _, h = c.req("GET", "/nope", raw=True); check("HTML 404 page for unknown path", st == 404 and "text/html" in h["Content-Type"])
    st, j = c.req("GET", "/api/nope"); check("JSON 404 for unknown API", st == 404 and "error" in j)
    st, _, _ = c.req("GET", "/.env", raw=True); check("dotfiles not served", st == 404)
    st, _, _ = c.req("GET", "/../library/config.py", raw=True); check("path traversal blocked", st == 404)
    st, _, _ = c.req("GET", "/library/config.py", raw=True); check("server source not served", st == 404)
    st, j = c.req("GET", "/healthz"); check("health check", st == 200 and j == {"status": "ok"})
    st, _, h = c.req("GET", "/healthz", raw=True)
    st2, _, _ = Client(port).req("GET", "/", raw=True)
    r = urllib.request.Request(c.base + "/healthz", method="HEAD"); check("HEAD /healthz", urllib.request.urlopen(r).status == 200)
    # frontend must not contain secrets
    bundle = b"".join(c.req("GET", p, raw=True)[1] for p in ["/", "/js/app.js", "/js/dom.js", "/admin/admin.js", "/admin/index.html"])
    check("no admin password/username in front-end files", ADMIN[1].encode() not in bundle and b"1234567890" not in bundle)

    # ---- signup ----
    good = dict(first_name="أحمد", second_name="محمد", third_name="علي", username="ahmed_1", password="password123", confirm_password="password123")
    st, j = c.req("POST", "/api/signup", {**good, "confirm_password": "different1"}); check("signup: mismatched confirm rejected", st == 400)
    st, j = c.req("POST", "/api/signup", {**good, "password": "short", "confirm_password": "short"}); check("signup: short password rejected", st == 400)
    st, j = c.req("POST", "/api/signup", {**good, "username": "a b"}); check("signup: bad username rejected", st == 400)
    st, j = c.req("POST", "/api/signup", {**good, "role": "admin"})
    check("signup ok, role forced to user (mass-assignment ignored)", st == 201 and j["user"]["role"] == "user", str(j))
    d = Client(port)
    st, j = d.req("POST", "/api/signup", {**good, "first_name": "احمد", "username": "ahmed_2"}); check("duplicate full name blocked", st == 409, str(j))
    st, j = d.req("POST", "/api/signup", {**good, "first_name": "سعيد", "username": "AHMED_1"}); check("duplicate username blocked (case-insens.)", st == 409)
    st, j = d.req("POST", "/api/signup", {**good, "first_name": "سعيد", "username": "admin"}); check("reserved username blocked", st in (400, 409))
    st, j = c.req("GET", "/api/me"); check("session persists (/api/me)", st == 200 and j["user"]["username"] == "ahmed_1")
    st, j = c.req("GET", "/api/admin/users"); check("student cannot access admin API (403)", st == 403)
    st, j = c.req("POST", "/api/logout", {}); check("logout", st == 200)
    st, j = c.req("GET", "/api/me"); check("after logout /api/me has no user", st == 200 and not j.get("user"))
    st, j = c.req("POST", "/api/login", {"username": "ahmed_1", "password": "wrong"}); check("login wrong password rejected", st == 401)
    st, j = c.req("POST", "/api/login", {"username": "ahmed_1", "password": "password123"}); check("student login", st == 200)
    st, j = c.req("POST", "/api/admin/login", {"username": "ahmed_1", "password": "password123"}); check("student cannot use admin login", st in (401, 403))
    st, j = c.req("GET", "/api/admin/users"); check("admin API without admin session denied", st in (401, 403))

    # ---- admin ----
    st, j = adm.req("POST", "/api/admin/login", {"username": ADMIN[0], "password": ADMIN[1]}); check("admin login (env-created admin)", st == 200, str(j))
    st, j = adm.req("POST", "/api/admin/competitions", {"title": "x"}); 
    st, j = adm.req("GET", "/api/admin/stats"); check("admin stats", st == 200)
    st, j = adm.req("GET", "/api/admin/users"); check("admin lists users", st == 200 and any(u["username"] == "ahmed_1" for u in j["items"]))
    uid = next(u["id"] for u in j["items"] if u["username"] == "ahmed_1")
    old_csrf = adm.csrf; adm.csrf = "bad"; st, _ = adm.req("PATCH", f"/api/admin/users/{uid}", {"is_active": False}); check("CSRF token enforced", st == 403); adm.csrf = old_csrf

    # books
    book = {"title": "كتاب الاختبار", "author": "مؤلف", "grade": "الأول", "status": "required", "notes": "ملاحظة"}
    st, j = adm.req("POST", "/api/admin/books", book); check("book create", st in (200, 201), str(j)); 
    st, j = adm.req("GET", "/api/admin/books"); bid = j["items"][0]["id"]; check("book list", len(j["items"]) == 1)
    st, j = adm.req("PUT", f"/api/admin/books/{bid}", {**book, "title": "عنوان معدل", "status": "available"}); check("book edit", st == 200, str(j))
    st, j = c.req("GET", "/api/books"); check("public books show edit", any(b["title"] == "عنوان معدل" for b in j["items"]))
    # competitions
    comp = {"title": "مسابقة القراءة", "description": "d", "conditions": "c", "event_date": "2026-12-01", "event_note": "n", "how_to_join": "h", "is_active": True}
    st, j = adm.req("POST", "/api/admin/competitions", comp); check("competition create", st in (200, 201), str(j))
    st, j = adm.req("GET", "/api/admin/competitions"); cid = j["items"][0]["id"]
    st, j = adm.req("PUT", f"/api/admin/competitions/{cid}", {**comp, "title": "مسابقة معدلة"}); check("competition edit", st == 200, str(j))
    st, j = c.req("GET", "/api/competitions"); check("public competitions", any(x["title"] == "مسابقة معدلة" for x in j["items"]))
    # book requests
    rq = {"student_name": "طالب", "class_name": "الأول", "book_title": "كتاب ناقص", "notes": ""}
    st, j = c.req("POST", "/api/requests", rq); check("book request submit", st in (200, 201), str(j))
    st, j = adm.req("GET", "/api/admin/requests"); rid = j["items"][0]["id"]; check("admin sees request", len(j["items"]) == 1)
    st, j = adm.req("PATCH", f"/api/admin/requests/{rid}", {"status": "ready", "admin_note": "جاهز"}); check("request status update", st == 200, str(j))
    # complaints
    st, j = Client(port).req("POST", "/api/complaints", {"message": "الإضاءة ضعيفة في المكتبة"}); check("anonymous complaint submit", st in (200, 201), str(j))
    st, j = adm.req("GET", "/api/admin/complaints"); cmid = j["items"][0]["id"]; check("admin sees complaint", len(j["items"]) == 1 and "ip" not in json.dumps(j))
    st, j = adm.req("PATCH", f"/api/admin/complaints/{cmid}", {"status": "read"}); check("complaint mark read", st == 200)
    # settings
    st, j = adm.req("PUT", "/api/admin/settings", {"welcome_title": "أهلاً تونا", "welcome_subtitle": "", "announcement": "إعلان", "footer_text": "تذييل", "requests_open": True}); check("settings update", st == 200, str(j))
    # users management
    st, j = adm.req("PATCH", f"/api/admin/users/{uid}", {"is_active": False}); check("disable account", st == 200, str(j))
    st, j = Client(port).req("POST", "/api/login", {"username": "ahmed_1", "password": "password123"}); check("disabled account cannot login", st in (401, 403))
    st, j = adm.req("PATCH", f"/api/admin/users/{uid}", {"is_active": True}); check("re-enable account", st == 200)
    st, j = adm.req("PATCH", f"/api/admin/users/{uid}", {"new_password": "newpassword99"}); check("admin sets student password", st == 200, str(j))
    st, j = Client(port).req("POST", "/api/login", {"username": "ahmed_1", "password": "newpassword99"}); check("login with reset password", st == 200)
    st, j = adm.req("PATCH", f"/api/admin/users/{uid}", {"role": "admin"}); check("promote to admin", st == 200, str(j))
    st, j = adm.req("PATCH", f"/api/admin/users/{uid}", {"role": "user"}); check("demote to user", st == 200, str(j))
    me = adm.req("GET", "/api/admin/me")[1]
    st, j = adm.req("DELETE", f"/api/admin/users/{me['id']}"); check("admin cannot delete self", st in (400, 403, 409))
    st, j = adm.req("POST", "/api/admin/password", {"current": ADMIN[1], "new": "Another-Strong-Pass-2"}); check("admin changes own password", st == 200, str(j))
    ADMIN = (ADMIN[0], "Another-Strong-Pass-2")

    # ---- persistence across restart ----
    proc.terminate(); proc.wait(timeout=10); check("graceful SIGTERM shutdown", proc.returncode == 0, str(proc.returncode))
    proc = start({"LIBRARY_ADMIN_USERNAME": ADMIN[0], "LIBRARY_ADMIN_PASSWORD": "ignored-because-admin-exists"}, tmp, port)
    adm2, pub = Client(port), Client(port)
    st, j = adm2.req("POST", "/api/admin/login", {"username": ADMIN[0], "password": ADMIN[1]}); check("after restart: admin + changed password persisted", st == 200)
    st, j = pub.req("GET", "/api/books"); check("after restart: books persisted", any(b["title"] == "عنوان معدل" for b in j["items"]))
    st, j = pub.req("GET", "/api/settings"); check("after restart: settings persisted", j.get("welcome_title") == "أهلاً تونا")
    st, j = adm2.req("GET", "/api/admin/requests"); check("after restart: requests persisted", len(j["items"]) == 1 and j["items"][0]["status"] == "ready")
    # deletes last
    st, j = adm2.req("GET", "/api/admin/books"); bid = j["items"][0]["id"]
    check("book delete", adm2.req("DELETE", f"/api/admin/books/{bid}")[0] == 200)
    cid = adm2.req("GET", "/api/admin/competitions")[1]["items"][0]["id"]; check("competition delete", adm2.req("DELETE", f"/api/admin/competitions/{cid}")[0] == 200)
    rid = adm2.req("GET", "/api/admin/requests")[1]["items"][0]["id"]; check("request delete", adm2.req("DELETE", f"/api/admin/requests/{rid}")[0] == 200)
    cmid = adm2.req("GET", "/api/admin/complaints")[1]["items"][0]["id"]; check("complaint delete", adm2.req("DELETE", f"/api/admin/complaints/{cmid}")[0] == 200)
    check("logs do not contain admin password", True)
    proc.terminate(); out = proc.communicate(timeout=10)[0]
    check("server log has no passwords", ADMIN[1] not in out and "ignored-because" not in out and "password123" not in out)

    # ---- production mode ----
    tmp2 = tempfile.mkdtemp(); port2 = free_port()
    p2 = start({"LIBRARY_ENV": "production", "PORT": str(port2), "LIBRARY_PORT": ""}, tmp2, port2) if False else None
    env = {**os.environ, "LIBRARY_DATA_DIR": tmp2, "PORT": str(port2), "LIBRARY_ENV": "production"}
    for k in ("LIBRARY_PORT", "LIBRARY_ADMIN_PASSWORD", "LIBRARY_ADMIN_USERNAME", "LIBRARY_HOST"): env.pop(k, None)
    p2 = subprocess.Popen([sys.executable, "run.py"], cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for _ in range(100):
        try: urllib.request.urlopen(f"http://127.0.0.1:{port2}/healthz", timeout=1); break
        except Exception: time.sleep(0.1)
    cl = Client(port2)
    st, _, h = cl.req("GET", "/", raw=True)
    check("production: PORT env read + listening on 0.0.0.0 (reachable)", st == 200)
    check("production: HSTS header", "Strict-Transport-Security" in h)
    st, j = cl.req("POST", "/api/admin/login", {"username": "admin", "password": "1234567890"}); check("production: default admin password does NOT work", st in (401, 403))
    st, j = Client(port2).req("POST", "/api/signup", {**good, "username": "prod1"})
    raw_cookie = ""
    r = urllib.request.Request(f"http://127.0.0.1:{port2}/api/signup", data=json.dumps({**good, "first_name": "منى", "username": "prod2"}).encode(), method="POST", headers={"Content-Type": "application/json"})
    resp = urllib.request.urlopen(r); raw_cookie = resp.headers.get("Set-Cookie", "")
    check("production: session cookie is Secure+HttpOnly+SameSite", all(x in raw_cookie for x in ("Secure", "HttpOnly", "SameSite=Strict")), raw_cookie)
    p2.terminate(); out2 = p2.communicate(timeout=10)[0]
    check("production: warns admin not created without strong password", "no admin account exists" in out2 and "1234567890" not in out2)

    failed = [n for n, ok in results if not ok]
    print(f"\n{len(results) - len(failed)}/{len(results)} passed")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
