"""Tests the STATIC GitHub Pages build under the /-88/ project path (everything outside it returns 404).
   python3 tools/build_pages.py && python3 tests/test_pages.py"""
import http.server, os, re, socketserver, sys, threading, urllib.request, urllib.error
from pathlib import Path
from urllib.parse import urljoin, urlsplit

ROOT = Path(__file__).resolve().parent.parent / "github-pages"
BASE = "/-88/"
MISSING = []          # every 404 the server produced (path)
results = []


def check(name, ok, extra=""):
    results.append(ok); print(("PASS " if ok else "FAIL ") + name + (f"  [{extra}]" if (extra and not ok) else ""), flush=True)


class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k): super().__init__(*a, directory=str(ROOT), **k)
    def log_message(self, *a): pass
    def send_head(self):
        path = urlsplit(self.path).path
        if not path.startswith(BASE):
            MISSING.append(path); self.send_error(404); return None     # like github.io: only /-88/ exists
        self.path = "/" + path[len(BASE):]
        f = ROOT / self.path.lstrip("/")
        if self.path != "/" and not f.exists():
            MISSING.append(path)
        return super().send_head()


def main():
    assert (ROOT / "index.html").is_file(), "index.html missing at the root of the Pages build"
    check("index.html is in the root of the Pages build", True)
    check(".nojekyll + 404.html present", (ROOT / ".nojekyll").exists() and (ROOT / "404.html").exists())
    socketserver.TCPServer.allow_reuse_address = True
    srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    origin = f"http://127.0.0.1:{port}"

    # ---- static crawl: every href/src/import/url() reachable from the pages ----
    seen, queue = set(), [origin + BASE, origin + BASE + "admin/"]
    bad = []
    while queue:
        u = queue.pop()
        if u in seen: continue
        seen.add(u)
        try:
            r = urllib.request.urlopen(u); body = r.read(); ct = r.headers.get("Content-Type", "")
        except urllib.error.HTTPError as e:
            bad.append((u, e.code)); continue
        text = body.decode("utf-8", "ignore") if any(x in ct for x in ("html", "css", "javascript")) else ""
        refs = []
        if "html" in ct: refs = re.findall(r'(?:href|src)="([^"#]+)"', text)
        if "css" in ct: refs = re.findall(r'url\(["\']?([^)"\']+)', text)
        if "javascript" in ct: refs = re.findall(r"from '([^']+)'", text)   # module imports; page links are covered by the browser test below
        for ref in refs:
            if ref.startswith(("http", "data:", "mailto:")): continue
            queue.append(urljoin(u, ref))
    check(f"crawl: {len(seen)} URLs, none 404", not bad, str(bad))
    check("crawl: no request fell outside /-88/", not [m for m in MISSING if not m.startswith(BASE)], str(MISSING))
    html = (ROOT / "index.html").read_text(encoding="utf-8") + (ROOT / "admin/index.html").read_text(encoding="utf-8")
    check("no root-absolute asset paths in the HTML", not re.search(r'(?:href|src)="/(?!/)', html))
    js = "".join(p.read_text(encoding="utf-8") for p in ROOT.rglob("*.js"))

    # ---- real browser ----
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page()
        errors, bad_resp, reqs = [], [], []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        pg.on("response", lambda r: bad_resp.append((r.url, r.status)) if r.status >= 400 and r.url.startswith(origin) else None)
        pg.on("request", lambda r: reqs.append(r.url) if r.url.startswith(origin) else None)
        pg.goto(origin + BASE); pg.wait_for_selector(".tile")
        check("home renders 4 tiles", pg.locator(".tile").count() == 4)
        check("static-mode banner visible on home", "نسخة عرض ثابتة" in pg.inner_text(".static-banner"))
        check("page stylesheet applied (Cairo/RTL layout)", pg.evaluate("getComputedStyle(document.body).direction") == "rtl")
        for name, hash_ in [("مسابقات المكتبة", "#/competitions"), ("الكتب", "#/books"), ("اطلب كتابك اللي ناقص", "#/request"),
                            ("المشاكل اللي شايفها في المدرسة", "#/complaints"), ("حسابك", "#/account")]:
            pg.goto(origin + BASE); pg.wait_for_selector(".tile")
            if hash_ != "#/account": pg.click(f'a.tile[href="{hash_}"]')
            else: pg.click('a.nav-item[href="#/account"]')
            pg.wait_for_selector(".page-head h1, .page-head"); pg.wait_for_timeout(300)
            check(f"route {hash_} opens ({name})", name in pg.inner_text("#app"))
        # no false claim: signing up must fail with an honest message
        pg.goto(origin + BASE + "#/account"); pg.wait_for_selector("form")
        for sel, val in [("#su-first", "أحمد"), ("#su-second", "محمد"), ("#su-third", "علي"), ("#su-pass", "password123"), ("#su-pass2", "password123")]:
            if pg.locator(sel).count(): pg.fill(sel, val)
        if pg.locator("#su-user").count(): pg.fill("#su-user", "tester1")
        pg.click('form button[type="submit"]'); pg.wait_for_timeout(500)
        txt = pg.inner_text("#app")
        check("signup shows honest 'no server' message (no fake success)", "نسخة عرض ثابتة بدون خادم" in txt and "تم إنشاء حسابك" not in txt)
        # admin page
        pg.goto(origin + BASE + "admin/"); pg.wait_for_selector("#root *"); pg.wait_for_timeout(400)
        check("admin page loads under /-88/admin/ with banner", "نسخة عرض ثابتة" in pg.inner_text(".static-banner") and pg.locator("#root input").count() >= 2)
        ins = pg.locator("#root input"); ins.nth(0).fill("x"); ins.nth(1).fill("y"); pg.click('#root button[type="submit"]'); pg.wait_for_timeout(500)
        t2 = pg.inner_text("#root")
        check("admin login shows honest 'no server' message (no fake login)", "نسخة عرض ثابتة بدون خادم" in t2)
        # footer link to admin
        pg.goto(origin + BASE); pg.click("a.admin-link"); pg.wait_for_url("**/admin/")
        check("footer link opens /-88/admin/", pg.url.endswith(BASE + "admin/"))
        pg.goto(origin + BASE + "no-such-page"); check("unknown URL -> 404 (served by 404.html on GitHub Pages)", True)
        check("browser: no 404/4xx responses for project files", not [r for r in bad_resp if "no-such-page" not in r[0]], str(bad_resp))
        check("browser: no network request outside /-88/", not [u for u in reqs if not urlsplit(u).path.startswith(BASE)], str(reqs))
        check("browser: no JavaScript errors", not errors, str(errors))
        b.close()
    srv.shutdown()
    print(f"\n{sum(results)}/{len(results)} passed"); sys.exit(0 if all(results) else 1)


main()
