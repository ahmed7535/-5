#!/usr/bin/env python3
"""Build the STATIC front-end copy for GitHub Pages from ./static  ->  ./github-pages

    python3 tools/build_pages.py [--base /-88/] [--out github-pages]

- index.html ends up in the root of the output folder.
- Every asset path is made RELATIVE, so it works under a project path such as /-88/.
- The copy has NO backend: api() never touches the network and reports clearly that
  sign-in / books / requests need the Python server (the Render deployment).
The original ./static folder and the Python project are not modified.
"""
import argparse
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BANNER = ('<div class="static-banner" role="note">نسخة عرض ثابتة (GitHub Pages): الواجهة فقط. '
          'تسجيل الدخول وإنشاء الحسابات والكتب والمسابقات والطلبات تحتاج خادم المكتبة (Python) وقاعدة بياناته، '
          'وهي غير متصلة هنا.</div>\n')
CSS_EXTRA = """
/* static (GitHub Pages) build only */
.static-banner { background: #fff4d6; color: #5c4300; border-bottom: 1px solid #e6c870; padding: 10px 16px;
  text-align: center; font-size: 14px; line-height: 1.6; position: relative; z-index: 5; }
"""
NO_BACKEND_JS = """
// ---- STATIC BUILD: there is no backend on GitHub Pages. Never pretend, never fire requests. ----
export async function api() {
  throw new ApiError(0, 'هذه نسخة عرض ثابتة بدون خادم: لا يمكن تسجيل الدخول أو حفظ أو جلب بيانات هنا. استخدم النسخة الكاملة المنشورة على استضافة Python.');
}
"""


def sub(text, pairs):
    for old, new in pairs:
        if old not in text:
            raise SystemExit(f"build_pages: expected text not found: {old!r}")
        text = text.replace(old, new)
    return text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="/-88/", help="project path on GitHub Pages (used only by 404.html)")
    ap.add_argument("--out", default="github-pages")
    args = ap.parse_args()
    base = "/" + args.base.strip("/") + "/" if args.base.strip("/") else "/"
    src, out = ROOT / "static", ROOT / args.out
    if out.exists():
        shutil.rmtree(out)
    shutil.copytree(src, out)

    # --- index.html (student site) ---
    p = out / "index.html"
    t = sub(p.read_text(encoding="utf-8"), [
        ('href="/favicon.svg"', 'href="favicon.svg"'),
        ('href="/css/style.css"', 'href="css/style.css"'),
        ('src="/js/app.js"', 'src="js/app.js"'),
        ('href="/admin/"', 'href="admin/"'),
        ('<body class="has-nav">\n', '<body class="has-nav">\n' + BANNER),
    ])
    p.write_text(t, encoding="utf-8")

    # --- admin/index.html ---
    p = out / "admin" / "index.html"
    t = sub(p.read_text(encoding="utf-8"), [
        ('href="/favicon.svg"', 'href="../favicon.svg"'),
        ('href="/css/style.css"', 'href="../css/style.css"'),
        ('href="/admin/admin.css"', 'href="admin.css"'),
        ('src="/admin/admin.js"', 'src="admin.js"'),
        ('<body class="admin">\n', '<body class="admin">\n' + BANNER),
    ])
    p.write_text(t, encoding="utf-8")

    # --- JS ---
    p = out / "admin" / "admin.js"
    p.write_text(sub(p.read_text(encoding="utf-8"), [("from '/js/dom.js'", "from '../js/dom.js'")]), encoding="utf-8")
    p = out / "js" / "app.js"
    p.write_text(sub(p.read_text(encoding="utf-8"), [
        ("location.href = '/admin/';", "location.href = 'admin/';"),
        ("href: '/admin/'", "href: 'admin/'"),
    ]), encoding="utf-8")
    p = out / "js" / "dom.js"
    t = p.read_text(encoding="utf-8")
    i = t.index("export async function api(")
    j = t.index("export const REQUEST_STATUS")
    p.write_text(t[:i] + NO_BACKEND_JS.lstrip("\n") + "\n" + t[j:], encoding="utf-8")

    # --- CSS ---
    p = out / "css" / "style.css"
    p.write_text(p.read_text(encoding="utf-8") + CSS_EXTRA, encoding="utf-8")

    # --- GitHub Pages extras ---
    (out / ".nojekyll").write_text("", encoding="utf-8")
    (out / "404.html").write_text(f"""<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>404 — الصفحة غير موجودة</title>
<link rel="stylesheet" href="{base}css/style.css"></head>
<body><main style="min-height:80vh;display:grid;place-items:center;text-align:center;padding:24px">
<div><h1 style="font-size:64px;margin:0">404</h1><h2>الصفحة غير موجودة</h2>
<p><a class="btn gold" href="{base}">العودة إلى الصفحة الرئيسية</a></p></div></main></body></html>
""", encoding="utf-8")
    print(f"built {out}  (base {base})")


if __name__ == "__main__":
    main()
